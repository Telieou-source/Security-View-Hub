@echo off
setlocal EnableDelayedExpansion
title Threat-Intel Server

REM ── Change to the directory where this script lives ──────────────────────────
cd /d "%~dp0"

REM ── Check for .env ────────────────────────────────────────────────────────────
if not exist ".env" (
  echo.
  echo  ERROR: .env file not found.
  echo.
  echo  Run setup.bat first, or:
  echo    1. Copy .env.example to .env
  echo    2. Edit .env and set DATABASE_URL and SESSION_SECRET
  echo.
  pause
  exit /b 1
)

REM ── Load .env (skip blank lines and comments) ─────────────────────────────────
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  set "line=%%A"
  if not "!line!"=="" (
    set "first=!line:~0,1!"
    if not "!first!"=="#" (
      set "%%A=%%B"
    )
  )
)

REM ── Defaults ──────────────────────────────────────────────────────────────────
set NODE_ENV=production
if "%PORT%"=="" set PORT=3000

REM ── Validate DATABASE_URL ──────────────────────────────────────────────────────
if "%DATABASE_URL%"=="" (
  echo.
  echo  ERROR: DATABASE_URL is not set in .env
  echo  Edit .env and add: DATABASE_URL=postgres://user:pass@localhost:5432/threatintel
  echo.
  pause
  exit /b 1
)

echo.
echo  Starting Threat-Intel ^> http://localhost:%PORT%
echo  Press Ctrl+C to stop.
echo.

node server.mjs
if %ERRORLEVEL% neq 0 (
  echo.
  echo  Server exited with an error. Check the output above.
  pause
)
