@echo off
REM Threat-Intel — Windows launcher
REM Edit .env (copy from .env.example) before running.

if not exist ".env" (
  echo ERROR: .env file not found.
  echo Copy .env.example to .env and set DATABASE_URL.
  pause
  exit /b 1
)

REM Load variables from .env (simple key=value, no spaces around =)
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
)

set NODE_ENV=production
if "%PORT%"=="" set PORT=3000

echo Starting Threat-Intel server ^> http://localhost:%PORT%
node server.mjs
