@echo off
title Threat-Intel Server

REM ── Change to the directory where this script lives ──────────────────────────
cd /d "%~dp0"

REM ── Check for .env ────────────────────────────────────────────────────────────
if not exist ".env" (
  echo.
  echo  ERROR: .env file not found.
  echo.
  echo  Run setup.bat first, or:
  echo    1. Copy .env.example to .env
  echo    2. Edit .env and set DATABASE_URL and SESSION_SECRET
  echo.
  pause
  exit /b 1
)

echo.
echo  Starting Threat-Intel -- open http://localhost:3000
echo  Press Ctrl+C to stop.
echo.

REM ── Node 20+ loads .env natively; NODE_ENV forced to production ───────────────
set NODE_ENV=production
node --env-file=.env server.mjs
if %ERRORLEVEL% neq 0 (
  echo.
  echo  Server exited with an error. Check the output above.
  pause
)
