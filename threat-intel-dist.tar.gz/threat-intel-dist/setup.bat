@echo off
title Threat-Intel Setup
cd /d "%~dp0"

echo.
echo  Threat-Intel — First-Time Setup
echo  ================================
echo.

REM Check for PowerShell
where powershell >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo  ERROR: PowerShell is required but not found.
  echo  Please run setup.ps1 manually or configure .env by hand.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
pause
