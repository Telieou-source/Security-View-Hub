Global Threat-Intel CSV Aggregator
Air-Gapped Distribution
===================================

PREREQUISITES
─────────────
  • Node.js v18 or later
      Download: https://nodejs.org/en/download  (get the LTS offline installer)
  • PostgreSQL 13 or later
      Download: https://www.postgresql.org/download/

WINDOWS — QUICK START (Recommended)
─────────────────────────────────────
  1. Extract this zip to a folder (e.g. C:\threat-intel\)
  2. Double-click  setup.bat
       • Checks Node.js and PostgreSQL
       • Creates the .env configuration file
       • Creates the database and loads the schema automatically
  3. Double-click  start.bat
  4. Open http://localhost:3000

LINUX / MACOS — QUICK START
─────────────────────────────
  1. Extract the tarball:
       tar -xzf threat-intel-dist.tar.gz
       cd threat-intel-dist

  2. Create and initialise the database (first run only):
       createdb threatintel
       psql -U postgres -d threatintel -f schema.sql

  3. Configure:
       cp .env.example .env
       # Edit .env: set DATABASE_URL and SESSION_SECRET

  4. Start:
       ./start.sh

  5. Open http://localhost:3000

MANUAL SETUP (any OS)
──────────────────────
  1. Copy .env.example to .env and edit it:

       DATABASE_URL=postgres://username:password@localhost:5432/threatintel
       SESSION_SECRET=<any long random string>
       PORT=3000           (optional — default is 3000)

  2. Create the database and load schema:

       createdb threatintel
       psql -U postgres -d threatintel -f schema.sql

  3. Start the server:

       node server.mjs

IMPORTING THREAT FEEDS
──────────────────────
  Use the Import page to:
    • Upload a CSV / TXT / RAW file directly from disk
    • Paste raw feed text
    • Enter a local-network URL (if available inside the air-gap)

  Supported formats include:
    • PhishTank CSV export
    • URLhaus CSV / plain-text
    • Blocklist.de plain-text
    • MISP event exports
    • Any headerless one-indicator-per-line file
    • Hash lists (MD5 / SHA1 / SHA256)
    • Space- or #-delimited formats

  All data is stored locally in your PostgreSQL database.
  No internet connection is required after setup.

EXPORTING DATA
──────────────
  Use the Export page to download your indicators as CSV, JSON, or a
  full air-gapped bundle for transfer to another machine.

UPGRADING
─────────
  1. Replace all files EXCEPT .env with files from the new package.
  2. Run schema.sql again (safe to re-run — uses IF NOT EXISTS):
       psql -U postgres -d threatintel -f schema.sql
  3. Restart the server.

