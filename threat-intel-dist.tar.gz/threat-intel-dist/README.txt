Global Threat-Intel CSV Aggregator
Air-Gapped Distribution
===================================

PREREQUISITES
─────────────
  • Node.js v18 or later
      Download: https://nodejs.org/en/download  (get offline installer)
  • PostgreSQL 13 or later
      Download: https://www.postgresql.org/download/

FIRST-TIME SETUP
────────────────
  1. Create a PostgreSQL database:

       createdb threatintel
       (or use pgAdmin / another GUI tool)

  2. Load the schema (run once):

       psql -U postgres -d threatintel -f schema.sql

  3. Configure the server:

       cp .env.example .env

       Then edit .env and set at minimum:
         DATABASE_URL=postgres://postgres:<password>@localhost:5432/threatintel
         SESSION_SECRET=<any long random string>

STARTING THE SERVER
───────────────────
  Linux / macOS:
    ./start.sh

  Windows:
    Double-click start.bat  (or run it from a Command Prompt)

  Manual (any OS):
    set NODE_ENV=production
    set PORT=3000
    set DATABASE_URL=postgres://...
    node server.mjs

  Then open a browser at:  http://localhost:3000

IMPORTING THREAT FEEDS
──────────────────────
  Use the Import page to:
    • Upload a CSV / TXT / RAW file directly from disk
    • Paste raw feed text
    • Enter a local-network URL (if available inside the air-gap)

  Supported formats include:
    • PhishTank CSV export
    • URLhaus CSV / plain-text
    • Blocklist.de plain-text
    • MISP event exports
    • Any headerless one-indicator-per-line file
    • Hash lists (MD5 / SHA1 / SHA256)
    • Space- or #-delimited formats

  All data is stored locally in your PostgreSQL database.
  No internet connection is required after setup.

EXPORTING DATA
──────────────
  Use the Export page to download your indicators as CSV or JSON for
  use in other tools (SIEMs, firewalls, etc.).

UPGRADING
─────────
  1. Replace all files EXCEPT .env and schema.sql with the new package.
  2. Run schema.sql again — all CREATE TABLE statements use IF NOT EXISTS
     so they are safe to re-run and will only add new tables/columns.
  3. Restart the server.

