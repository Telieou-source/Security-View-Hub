#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Auto-load .env if it exists in the same directory
if [ -f "${SCRIPT_DIR}/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "${SCRIPT_DIR}/.env"
  set +a
fi

export NODE_ENV=production
export PORT="${PORT:-3000}"

if [ -z "${DATABASE_URL:-}" ]; then
  echo ""
  echo "ERROR: DATABASE_URL is not set."
  echo ""
  echo "  1. Copy .env.example to .env"
  echo "  2. Edit .env and set DATABASE_URL to your PostgreSQL connection string"
  echo "  3. If this is a first run, initialise the database:"
  echo "       psql -U <user> -d <dbname> -f schema.sql"
  echo ""
  exit 1
fi

echo "Starting Threat-Intel server → http://localhost:${PORT}"
exec node "${SCRIPT_DIR}/server.mjs"
